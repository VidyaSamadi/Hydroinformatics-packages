function [SimRR] = sacmodel(x,Extra);
% Recursive running of the SACSMA model

% First initialize States
States = 0.5*[x(1) x(2) x(8) x(9) x(10) (x(1)+x(8))];

% Run SAC-SMA model
[SimRR,SimStates] = sacsma(x,States,Extra.Obs); SimRR = SimRR(65:795,1);