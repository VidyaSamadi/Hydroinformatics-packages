function [Extra] = Init_ConsSVD_Tau(Extra) ;

% Define matrix of constraints: mass constraint, and increment tending to zero along the boundaries of the subregion containing the plume
%  Mass constraint
A=[1,zeros(1,(Extra.order+1)^Extra.dim-1)];

% Constraints on 4 corners
% Values taken of Legendre polynomials at boundary (-1 1) for orders 0 to 7
valueC = [1 1; -1 1; 1 1; -1 1; 1 1 ; -1 1;1 1;-1 1]; % n_values X n_orders
nrbC=2; % The two sides at corners
clear matrix;
for j=1:Extra.order+1 %y
    for i=1:Extra.order+1 %x
        nr=(j-1)*(Extra.order+1)+i; % Moment considered
        %Constraint loop:
        count=0;
        for jj=1:nrbC % Z
            for ii=1:nrbC % X
                count=count+1; 
                matrix(nr,count)=valueC(j,jj)*valueC(i,ii);
            end
        end
    end
end

A=[A;matrix'];

% Constraints on 4 edges
% Values taken of Legendre polynomials along edges for each order (0 to 7):
locE=[-.9,-0.75,-0.5,-0.25,0,0.25,0.5,0.75,0.9];
valueS=[ones(size(locE));locE;0.5.*(3.*locE.^2-1);0.5.*(5.*locE.^3-3.*locE);(1/8).*(35.*locE.^4-30.*locE.^2+3);...
    (1/8).*(63.*locE.^5-70.*locE.^3+15.*locE);(231.*locE.^6-315*locE.^4+105*locE.^2-5)./16;(429.*locE.^7-693.*locE.^5+315*locE.^3-35.*locE)./16];
nrbE=length(locE); % The values along edges and on side grids

% X turn
for j=1:Extra.order+1 %y
    for i=1:Extra.order+1 %x
        nr=(j-1)*(Extra.order+1)+i; % Moment considered
        %Constraint loop:
        count=0;
        for jj=1:nrbC % Z
            for ii=1:nrbE % X
                count=count+1; 
                matrix(nr,count)=valueC(j,jj)*valueS(i,ii);
            end
        end
    end
end
A=[A;matrix'];

% Z turn
for j=1:Extra.order+1 %y
    for i=1:Extra.order+1 %x
        nr=(j-1)*(Extra.order+1)+i; % Moment considered
        %Constraint loop:
        count=0;
        for jj=1:nrbE % Z
            for ii=1:nrbC % X
                count=count+1; 
                matrix(nr,count)=valueS(j,jj)*valueC(i,ii);
            end
        end
    end
end
A=[A;matrix'];

clear matrix 

% Define d
Extra.d=zeros(size(A,1),1); % Note that the mass constraint will be inserted later on in the function GenModel.m

% Do SVD of the constraint matrix A
[U,S,V] = svd(A);

% Define the non-null and null spaces
[idx] = find(diag(S)./max(diag(S)) > 1e-6); % take k largest values using ratio lambda/max(lambda) > 1e-6
%idx=find(sum(S,1)>0); idx0=find(sum(S,1)==0); % take non-zero values
Extra.Sp=S(idx,idx);

% Define the basis vectors spanning the space the constraints (U) and model (V)
Extra.Vp=V(:,idx);Extra.V0=V(:,idx(end)+1:end);
Extra.Up=U(:,idx);Extra.U0=U(:,idx(end)+1:end);

% Compute the Tau matrix only once on the finest mesh
[Extra.Tau]=CompTau(Extra.order,Extra.GridPar,Extra.dim);

Extra.nalpha=size(Extra.V0,2); % Number alpha coefficients to be inferred
