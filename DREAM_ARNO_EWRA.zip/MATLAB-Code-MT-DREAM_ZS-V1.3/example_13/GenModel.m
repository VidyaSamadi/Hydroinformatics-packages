function [model] = GenModel(GridPar,PosiPar,mass,alpha,Vp,Sp,Up,d,V0,Tau,interp_method);
% Function to generate a delta_theta model (see page 3 of Laloy et al. (2012))

nx=GridPar(1);  
nz=GridPar(2);
dx=GridPar(3);  
dz=GridPar(4);

% Estimated anomaleous area parameters:
startx=PosiPar(1); % Cells to remove in the beginning of the grid
startz=PosiPar(2);
stopx=PosiPar(3); % Cells to remove at the end of the grid
stopz=PosiPar(4);

nxt=nx-startx-stopx; % Size of anomalous grids
nzt=nz-startz-stopz;

dxt=2/(nx); % Discretization of transformed normalized grid (the one used to calculate Tau):
dzt=2/(nz);

% Physical discretization of the reduced grid (the one to use for rescaling of mass):
dxti=dx*(nx-startx-stopx)/nx;
dzti=dz*(nz-startz-stopz)/nz;

% Transformation of plume mass constraint to considered Legendre mesh:
d(1)=(mass/4)*(dxt/dxti)*(dzt/dzti);

% Reconstruct the Legendre moments (lambda) from the alpha coefficients:
lambda_R=(Vp/Sp)*Up'*d + V0*alpha ;

% Reconstruct model values:
mt_OverScaled=(Tau*lambda_R);

% Assign model to the over-scaled proposal model grid
model_OverScaled=zeros(nz,nx);
for j=1:nz
    for i=1:nx
        model_OverScaled(j,i)=mt_OverScaled((j-1)*nx+i);
    end
end

% Rescale according to the proposed size of the anomalous region (finer discretization than dx, dz, etc.)
xivt=startx*dx+dxti/2:dxti:(nx-stopx)*dx-dxti/2; 
zivt=startz*dz+dzti/2:dzti:(nz-stopz)*dz-dzti/2;
[xit,zit]=meshgrid(xivt,zivt);

xivtt=startx*dx+dx/2:dx:(nx-stopx)*dx-dx/2; % The original grid
zivtt=startz*dz+dz/2:dz:(nz-stopz)*dz-dz/2;
[xitt,zitt]=meshgrid(xivtt,zivtt);

% Interpolation from fine anomalous subregion of the grid to the coarser grid covering this region:
model_Scaled = interp2(xit,zit,model_OverScaled,xitt,zitt,interp_method);

% Assign model to the correct proposal model grid
model=0*ones(nz,nx);
for j=1:nzt
    for i=1:nxt
        model(j+startz,i+startx)=model_Scaled(j,i);
    end
end

