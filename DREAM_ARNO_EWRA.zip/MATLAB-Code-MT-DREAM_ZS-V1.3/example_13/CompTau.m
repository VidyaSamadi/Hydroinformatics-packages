function [Tau] = CompTau(order,GridPar,dim);
% Function to estimate the Tau matrix (see Eq. (5) of Laloy et al., 2012)

nx=GridPar(1);  
nz=GridPar(2);
dx=GridPar(3);  
dz=GridPar(4);

dxt=2/nx; % Discretization of the transformed normalized grid (to vary between -1 and 1)
dzt=2/nz;

% Calculate the Legendre polynomials
% x-direction (numerical integration over discretized intervals)
discrete=-1+dxt/2:dxt:1-dxt/2;
for i=0:order
    for j=1:nx
        dum=legendre(i,discrete(j)-dxt/2+dxt/21:dxt/21:discrete(j)+dxt/2-dxt/21);
        legend_polyx(i+1,j)=sum(dum(1,:));
        if i==0 & j==1
           faktor=legend_polyx(1,1); 
        end
        legend_polyx(i+1,j)=legend_polyx(i+1,j)/faktor;
    end
end

% z-direction
discrete=-1+dzt/2:dzt:1-dzt/2;
for i=0:order
    for j=1:nz
        dum=legendre(i,discrete(j)-dzt/2+dzt/21:dzt/21:discrete(j)+dzt/2-dzt/21);
        legend_polyz(i+1,j)=sum(dum(1,:));
        if i==0 & j==1
           faktor=legend_polyz(1,1); 
        end
        legend_polyz(i+1,j)=legend_polyz(i+1,j)/faktor;
    end
end

% Compute Tau matrix
Tau=zeros(nx*nz,(order+1)^dim);
for q=1:order+1
    for p=1:order+1
        ind_moment=(q-1)*(order+1)+p;
        for j=1:nz
            for i=1:nx
                elem=(j-1)*nx+i;
                Tau(elem,ind_moment)=legend_polyz(q,j)*legend_polyx(p,i);
            end
        end
    end
end

