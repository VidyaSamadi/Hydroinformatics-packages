dd=Extra.GridPar(3);
nn=length(Extra.datasim);

% Check convergence statistics
figure(1)
numb=nnz(output.R_stat(:,1));
plot(output.R_stat(1:numb,1),output.R_stat(1:numb,2:MCMCPar.n));
hold on
plot(output.R_stat(1:numb,1),1.2*ones(numb,1),'r','LineWidth',3);
hold off
title('G-R convergence stat.')
ylabel('Gelman-Rubin R');
xlabel('Function evaluation');
ylim([0.8 3]);

figure(2)
numb=nnz(output.AR(:,1));
plot(output.AR(1:numb,1),output.AR(1:numb,2),'k');
title('Acceptance rate')
ylabel('Acceptance rate (%)');
xlabel('Function evaluation');

% Plot true original model
figure(3)
model=Extra.dW + Extra.W0;
nx=Extra.GridPar(1);
nz=Extra.GridPar(2);
dx=Extra.GridPar(3);
dz=Extra.GridPar(4);
for k=1:nz
    zpatch(1,1)=Extra.ziv(k);
    zpatch(2,1)=Extra.ziv(k)+dz;
    zpatch(3,1)=Extra.ziv(k)+dz;
    zpatch(4,1)=Extra.ziv(k);
    for i=1:nx
        xpatch(1,1)=Extra.xiv(i);
        xpatch(2,1)=Extra.xiv(i);
        xpatch(3,1)=Extra.xiv(i)+dx;
        xpatch(4,1)=Extra.xiv(i)+dx;
        patch(xpatch(:,1),-zpatch(:,1),model(k,i),'LineStyle','none')
    end
end
xlabel('Distance (m)')
ylabel('Depth (m)')
%ylim([-3 0])
axis('equal')
title('True model')
caxis([0 0.2])
colorbar

% Plot maximum a posteriori (MAP) model
idx=find(ParSet(:,end)==max(ParSet(:,end)));
pars=ParSet(idx(1),1:end-2);
startx=round(pars(1)); 
startz=round(pars(2));
stopx=round(pars(3)); 
stopz=round(pars(4));
alpha=pars(5:end)';
PosiPar=[startx,startz,stopx,stopz];
interpolation_method='linear';
[delta_model]=GenModel(Extra.GridPar,PosiPar,Extra.mass,alpha,Extra.Vp,Extra.Sp,Extra.Up,Extra.d,Extra.V0,Extra.Tau,interpolation_method);
% Calculatate total mass in recovered image
mass_recomputed=sum((delta_model(:)))*dx*dz
% Build the full proposed model=W0+delta_model
prop_model=Extra.W0+delta_model;

figure(4)
for k=1:nz
    zpatch(1,1)=Extra.ziv(k);
    zpatch(2,1)=Extra.ziv(k)+dz;
    zpatch(3,1)=Extra.ziv(k)+dz;
    zpatch(4,1)=Extra.ziv(k);
    for i=1:nx
        xpatch(1,1)=Extra.xiv(i);
        xpatch(2,1)=Extra.xiv(i);
        xpatch(3,1)=Extra.xiv(i)+dx;
        xpatch(4,1)=Extra.xiv(i)+dx;
        patch(xpatch(:,1),-zpatch(:,1),prop_model(k,i),'LineStyle','none')
    end
end
xlabel('Distance (m)')
ylabel('Depth (m)')
%ylim([-3 0])
axis('equal')
title('MAP model')
caxis([0 0.2])
colorbar
%
% Plot 9 (randomly chosen) posterior model realizations
tau=0.5;P=ParSet(round(tau*size(ParSet,1)):end,1:end-2); % Select the last 50% of the generated samples as being drawn from the posterior 
                                                         % (assuming the MCMC sampling has converged -> needs be to checked by the Gelman-Rubin R stat)
q=randperm(size(P,1)); idx_pars=q(1:9); % Randomly select 9 realizations
figure(5)
for kk=1:9
    subplot(3,3,kk)
    [delta_model]=GenModel(Extra.GridPar,round(P(idx_pars(kk),1:4)),Extra.mass,P(idx_pars(kk),5:end)',Extra.Vp,Extra.Sp,Extra.Up,Extra.d,Extra.V0,Extra.Tau,'linear');
    prop_model=Extra.W0+delta_model;
    for k=1:nz
        zpatch(1,1)=Extra.ziv(k);
        zpatch(2,1)=Extra.ziv(k)+dz;
        zpatch(3,1)=Extra.ziv(k)+dz;
        zpatch(4,1)=Extra.ziv(k);
        for i=1:nx
            xpatch(1,1)=Extra.xiv(i);
            xpatch(2,1)=Extra.xiv(i);
            xpatch(3,1)=Extra.xiv(i)+dx;
            xpatch(4,1)=Extra.xiv(i)+dx;
            patch(xpatch(:,1),-zpatch(:,1),prop_model(k,i),'LineStyle','none')
        end
    end
    xlabel('Distance (m)')
    ylabel('Depth (m)')
    %ylim([-3 0])
    axis('equal')
    title(['Posterior realization ',num2str(kk)]);
    caxis([0 0.2])
    colorbar
end


