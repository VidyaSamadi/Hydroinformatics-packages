function [log_likelihood]=Legendre_GPR(Pars, Extra)

% First get parameters
startx=round(Pars(1)); % Cells to remove in the beginning of the grid
startz=round(Pars(2));
stopx=round(Pars(3)); % Cells to remove at the end of the grid
stopz=round(Pars(4));
PosiPar=[startx,startz,stopx,stopz];

alpha=Pars(5:end)';

% Now generate a delta_model(j,i) model
interpolation_method='linear';
[delta_model]=GenModel(Extra.GridPar,PosiPar,Extra.mass,alpha,Extra.Vp,Extra.Sp,Extra.Up,Extra.d,Extra.V0,Extra.Tau,interpolation_method);

% Calculatate total mass in recovered image
% mass_recomputed=sum((delta_model(:)))*dx*dz

% Build the full proposed model=background + increment
prop_model=Extra.W0+delta_model;

% Now check the plausibilty of the proposed model
minvalue=min(min(prop_model));
maxvalue=max(max(prop_model));

slowprop=prop_model*sqrt(Extra.pw)+(Extra.por-prop_model)*sqrt(Extra.pa)+(1-Extra.por)*sqrt(Extra.ps); % sqrt of effective permittivity
slowprop=slowprop./0.3; % Proposed slowness field (ns/m)

data=Extra.J*slowprop(:)-Extra.datasim; % Calculate residuals
data=data./Extra.error; % Calculate weighted residuals
log_likelihood=sum(data.^2); % Calculate log-likelihood

if minvalue<(0)
    log_likelihood=log_likelihood*(1+abs(minvalue)/0.01); % Penalty of models outside range
end

if maxvalue>(Extra.por)
    log_likelihood=log_likelihood*(1+maxvalue/(Extra.por)); % Penalty of models outside range
end

log_likelihood=-1/2*log_likelihood;

