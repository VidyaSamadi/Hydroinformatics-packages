function [SimRR] = hymodFORTRAN(x,Extra); 
% Runs the FORTRAN HYMOD model and returns the simulated discharge

% Write the parameter values to a file Param.in
dlmwrite('Param.in',x,'delimiter',' ');

% Execute the model -- this model reads the current parameter values from Param.in
dos('HYMODsilent.exe');

% Load the output of the model 
SimRR=load('Q.out'); SimRR = SimRR(65:Extra.MaxT,1);