function [SimRR] = ARNO(Pars,Extra)
% Written by Sadegh SadeghiTabas
    fid = fopen('kas.txt', 'r');
    line1= fgetl(fid);
  
    line2= fgetl(fid);

    line3= fgetl(fid); 

    line4= fgetl(fid); 
    line4=str2num(line4);
    line5= fgetl(fid); 
  
    line6= fgetl(fid); 
    line6=str2num(line6);
    line7= fgetl(fid); 
  
    line8= fgetl(fid); 
    %line8=str2num(line8);
    line9= fgetl(fid); 
 
    line10= fgetl(fid);
    line10=str2num(line10);
    line11= fgetl(fid); 
    line11=str2num(line11);
	line12= fgetl(fid); 
   
	line13= fgetl(fid); 
    line13=str2num(line13); 
	line14= fgetl(fid); 
    line14=str2num(line14);
	line15= fgetl(fid); 
    %line15=str2num(line15);
	
    fclose(fid);
    line10(1)=Pars(1,1);
    line10(2)=Pars(1,2);
    line10(3)=Pars(1,3);
    line11(1)=Pars(1,4);
    line11(2)=Pars(1,5);
    line11(3)=Pars(1,6);
    line13(1)=Pars(1,7);
    line13(2)=Pars(1,8);
    line13(3)=Pars(1,9);
	line13(4)=Pars(1,10);
	line13(5)=Pars(1,11);
	line14(1)=Pars(1,12);
	line14(2)=Pars(1,13);
	line14(3)=Pars(1,14);
	line14(4)=Pars(1,15);

    fid = fopen('kas.txt', 'wt');
    format short;
    fprintf(fid, '%s\n',abs( line1));
    fprintf(fid, '%s\n',abs( line2));
    fprintf(fid, '%s\n',abs (line3));
    fprintf(fid, '%2g\n',abs (line4));
    fprintf(fid, '%s\n',abs (line5));
    fprintf(fid, '%2g\n',abs (line6));
    fprintf(fid, '%s\n',abs (line7));
    %fprintf(fid, '%5.2g%8.1g%6g\n', line8);
    fprintf(fid, '%s\n',abs (line8));
    fprintf(fid, '%s\n',abs (line9));
    fprintf(fid, '%5g%15.6g%15.6g\n',abs (line10));
    fprintf(fid, '%5g%15.4g%15.6g\n',abs( line11));
    fprintf(fid, '%s\n',abs (line12));
    fprintf(fid, '%5g%15.6g%15.6g%15.6g%15.5g\n',abs (line13));
    fprintf(fid, '%5g%15.5E%15.6g%15.6g\n',abs( line14));
    fprintf(fid, '%s\n',abs( line15));

    fclose(fid);
    % Call model 
    dos arno;
    
    %evalstr = ['ModPred = ',ModelName,'(x(ii,:),Extra);']; eval(evalstr);
    %ModPred=dlmread('kasoutput.txt');
    %SimRR=ModPred(2:end,:);
    fid1 = fopen('kasoutput.txt', 'r');
    tline = fgetl(fid1);
    num=0;
while ischar(tline)
    num=num+1;
    tline = fgetl(fid1);
end
fclose(fid1);
    fid2 = fopen('kasoutput.txt', 'r');
    fgetl(fid2);
for i=1:num-1
        lin(i,:)= fgetl(fid2);
      SimRR(i,1)=str2num(lin(i,:));
end
fclose(fid2);


